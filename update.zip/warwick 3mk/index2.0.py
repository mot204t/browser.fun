# main.py
import sys
import os
from PyQt5 import QtCore, QtWidgets, QtWebEngineWidgets


class Browser(QtWebEngineWidgets.QWebEngineView):

    def __init__(self):
        super().__init__()

        html = """
        <!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project0</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
<style>
        nav{
  height: 60px;
  width: 100%;
  background-color: #000000ad;

}

nav a {
  color:white;
  font-size: 17px;
  text-transform: uppercase;
  padding: 14px 14px;
  border-radius: 5px;
  margin: 0 5px;
  line-height: 60px;
  transition: 0.200s;
  text-decoration: none;
  
}


nav font{
  font-size: 50px;
}

nav a:hover {
  background-color: rgba(0, 0, 0, 0.829);
}
nav ul{
float: right;
margin-right: 20px;
}
nav ul li{
display: inline-block;
line-height: 60px;
margin: 0 5px;

}
nav ul li a {
color:white;
font-size: 17px;
text-transform: uppercase;
padding: 14px 14px;
border-radius: 5px;
}



.checkbtn{
  font-size: 30px;
  color: white;
  float: right;
  line-height: 60px;
}

.checkbtn{
  font-size: 40px;
  color: white;
  float: right;
  line-height: 60px;
  margin-right: 40px;
  cursor: pointer;
  display: none;
}
#check{
  display: none;
}
@media (max-width: 15360px){
  label.logo{
    font-size: 60x;
    padding-left: 60px;
    color: white;
  }
  nav ul li a{
    font-size: 16px;
  }
}
@media (max-width: 15360px){
  .checkbtn{
    display: block;
  }
  ul{
    position: fixed;
    width: 250px;
    height: 100vh;
    background: #080808a8;
    top: 44px;
    right: -100%;
    left: 10;
    text-align:center;
    transition: all .5s;
  

  }
  nav ul li{
    display: block;
    margin: 50px 0;
    line-height: 30px;
  }
  nav ul li a{
    font-size: 20px;
  }
  a:hover{
    background: none;
    color: #ffffff;
  }
  a.active{
      background: none;
      color: #ffffff;
    }
  #check:checked ~ ul{
    right: 0;
  }
}
.content{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  z-index: -1;
  width: 100%;
  padding: 0 30px;
  color: #1b1b1b;
}
.content div{
 font-size: 40px;
 font-weight: 700;
}
label.logo{
  font-size: 25px;
  text-transform: uppercase;
  padding: 14px 14px;
  border-radius: 20px;
  margin: 0 5px;
  line-height: 60px;
  user-select: none;
  font-size: 25px;
  color: white;
  background: white;
  background-size: 25px 25px;
  -webkit-text-fill-color: transparent;
  -webkit-background-clip: text;

}
.hover1 {
  font-size: 25px;
  color: white;
  background: white;
  background-size: 25px 25px;
  -webkit-text-fill-color: transparent;
  -webkit-background-clip: text;
}
section img{
    width: 200px;
    height: 350px;
}

.hover10 :hover img {
	-webkit-filter: grayscale(100%) blur(3px);
	filter: grayscale(100%) blur(3px);
}
body{
    overflow: hidden;
    margin: 0%;
    font-family: Arial, Helvetica, sans-serif;
    cursor: url(http://mot204t.42web.io/2.cur), default;
    cursor: url(http://mot204t.42web.io/2.cur), pointer;
    cursor: url(http://mot204t.42web.io/2.cur), crosshair;
    cursor: url(http://mot204t.42web.io/2.cur), auto;
    cursor: url(http://mot204t.42web.io/2.cur), context-menu;
    cursor: url(http://mot204t.42web.io/2.cur) cell;
}

section {
    display: none;
    padding: 2rem;
  }
  
section.active {
    display: block;
}

footer {
    background-color: #0c0c0c63;
    color: #fff;
    text-align: center;
    padding: 0.25rem;
    position: fixed;
    bottom: 0;
    width: 100%;
    }
.back-video{
    position: absolute;
    left: center;
    bottom: center;
    z-index: -1;
    

}
video{
    width: 100%;
    height: 99%;
}
a{
    cursor: url(2.cur), pointer;
    cursor: url(2.cur), default;
    cursor: url(2.cur), auto;
}


</style>
    <div class="back-video">
        <video autoplay loop muted plays-inline>
            <source src="http://mot204t.42web.io/vid1.mp4" type="video/mp4">
        </video>    
    </div>
    <nav>
        <label class="logo">Norilsk</label>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
        </label>
        <a onclick="showSection('#home')">Home</a>
        <a onclick="showSection('#about')">About</a>
        <ul>
            <a href="/ar">Arabic</a>
            <div class="h2">
                <a onclick="showSection('#downloads')">Downloads</a>
            </div>
        </ul>
    </nav>

    <section id="#home" class="active">
        <h2>Welcome to Your Website</h2>
        <p>Hello my friend, how are you doing?</p>
    </section>

    <section id="#about">
        <h2>Hello Freundin Zero4x</h2>
        <p>This is information about our company, services, or anything else you want to include.</p>
    </section>

    <section id="#downloads">
        <div class="hover1a">
                <a onclick="showSection('#clips-lol')"><img src="Lol.png">a</a><br>
                <a onclick="showSection('#clips-lol')"><img src="Lol.png">a</a><br>
        </div>
    </section>

    <footer>
        &copy; 2023 - 2024 mot204t Website. All rights reserved.
    </footer>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script>
        function showSection(sectionId) {
    document.querySelectorAll('section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}
    </script>
    <script>
        
    </script>
    
</body>
</html>

        """

        # With QWebEnginePage.setHtml, the html is loaded immediately.
        # baseUrl is used to resolve relative URLs in the document.
        # For whatever reason, it seems like the baseUrl resolves to
        # the parent of the path, not the baseUrl itself.  As a
        # workaround, either append a dummy directory to the base url
        # or start all relative paths in the html with the current
        # directory.
        # https://doc-snapshots.qt.io/qtforpython-5.15/PySide2/QtWebEngineWidgets/QWebEnginePage.html#PySide2.QtWebEngineWidgets.PySide2.QtWebEngineWidgets.QWebEnginePage.setHtml
        here = os.path.dirname(os.path.abspath(__file__)).replace('\\', '/')
        base_path = os.path.join(os.path.dirname(here), 'dummy').replace('\\', '/')
        self.url = QtCore.QUrl('file:///' + base_path)
        self.page().setHtml(html, baseUrl=self.url)


class MainWindow(QtWidgets.QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle('Project0')
        self.setFixedSize(1000,600)

        self.init_widgets()
        self.init_layout()

    def init_widgets(self):
        self.browser = Browser()


    def init_layout(self):
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self.browser)

        centralWidget = QtWidgets.QWidget()
        centralWidget.setLayout(layout)
        self.setCentralWidget(centralWidget)
        




if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())