function copyFunction() {
    var copyText = document.getElementById("myInput");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
} 
function cod4copyFunction() {
    var copyText = document.getElementById("cod4");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
} 
function mw2019copyFunction() {
    var copyText = document.getElementById("mw2019");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function mw3copyFunction() {
    var copyText = document.getElementById("mw3");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function mw2copyFunction() {
    var copyText = document.getElementById("mw2");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function mwrcopyFunction() {
    var copyText = document.getElementById("mwr");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function mw2crcopyFunction() {
    var copyText = document.getElementById("mw2cr");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function coldwarcopyFunction() {
    var copyText = document.getElementById("coldwar");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function bo4copyFunction() {
    var copyText = document.getElementById("bo4");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function bo3copyFunction() {
    var copyText = document.getElementById("bo3");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function bo2copyFunction() {
    var copyText = document.getElementById("bo2");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function bocopyFunction() {
    var copyText = document.getElementById("bo");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function ww2copyFunction() {
    var copyText = document.getElementById("ww2");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function wawcopyFunction() {
    var copyText = document.getElementById("waw");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function cod1copyFunction() {
    var copyText = document.getElementById("cod1");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function cod2copyFunction() {
    var copyText = document.getElementById("cod2");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function ghostscopyFunction() {
    var copyText = document.getElementById("ghosts");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function iwcopyFunction() {
    var copyText = document.getElementById("iw");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
function awcopyFunction() {
    var copyText = document.getElementById("aw");
    copyText.select();
copyText.setSelectionRange(0, 99999);
navigator.clipboard.writeText(copyText.value);
}
